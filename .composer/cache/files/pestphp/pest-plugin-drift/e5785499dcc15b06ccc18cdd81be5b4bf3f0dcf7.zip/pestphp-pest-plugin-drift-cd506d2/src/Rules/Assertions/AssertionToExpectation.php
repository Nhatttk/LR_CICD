<?php

declare(strict_types=1);

namespace Pest\Drift\Rules\Assertions;

/**
 * @internal
 */
final class AssertionToExpectation extends AbstractAssertionToExpectation {}
