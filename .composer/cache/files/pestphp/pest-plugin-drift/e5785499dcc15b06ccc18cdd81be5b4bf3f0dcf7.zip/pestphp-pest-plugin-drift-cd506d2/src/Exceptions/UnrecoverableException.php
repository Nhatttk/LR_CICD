<?php

declare(strict_types=1);

namespace Pest\Drift\Exceptions;

use Exception;

/**
 * @internal
 */
final class UnrecoverableException extends Exception
{
    //
}
